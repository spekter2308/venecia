<?php

return [
    'email'=> 'Адрес :attribute  почты должен быть действительный',
    'required'  => 'Поле :attribute  обязательное.',
];