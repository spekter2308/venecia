<?php

return [
    'email'=> 'Адреса :attribute  пошти повинен бути дійсна',
    'required'  => 'Поле :attribute  обов\'язкове.',
];