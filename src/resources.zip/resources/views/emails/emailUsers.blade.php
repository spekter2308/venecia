<h1>VENEZIA - {{$data['title']}} </h1>

<p>{!! $data['content']!!}</p>