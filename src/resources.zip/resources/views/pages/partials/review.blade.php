<div class="review-item">
    <div class="review-item-header"><strong>{{$review->name}}</strong> {{$review->created_at}}</div>
    <hr>
    <div class="review-item-message">{{$review->message}}</div>
</div>